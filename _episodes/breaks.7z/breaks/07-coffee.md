---
layout: break
title: "Morning Coffee"
teaching: 0
exercises: 0
break: 15
---
FIXME: describe what to reflect on.
